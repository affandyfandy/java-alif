package com.example.assignment_code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentCodeApplication.class, args);
	}

}

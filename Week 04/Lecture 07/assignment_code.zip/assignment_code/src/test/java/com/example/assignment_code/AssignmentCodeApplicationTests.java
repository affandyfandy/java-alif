package com.example.assignment_code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
